#pragma once
#include <iostream>
// MathFuncsLib.h

//============VECTOR2=================

//============VECTOR2=================








//===============VECTOR3==============


//===============VECTOR3==============


















//==============EXAMPLE=================
namespace MathFuncs
{
	class MyMathFuncs
	{
	public:
		// Returns a + b
		static double Add(double a, double b);

		// Returns a - b
		static double Subtract(double a, double b);

		// Returns a * b
		static double Multiply(double a, double b);

		// Returns a / b
		static double Divide(double a, double b);
	};
}
//==============EXAMPLE=================

























