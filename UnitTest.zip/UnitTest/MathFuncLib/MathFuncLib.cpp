
#include "stdafx.h"
#include "MathFuncLib.h"


using namespace std;


//===============================VECTOR 4=========================

//===============================VECTOR 4=========================












//=================Vector3 Initialization==========================














//=============VECTOR2==================




//============EXAMPLE===================
namespace MathFuncs
{
	double MyMathFuncs::Add(double a, double b)
	{
		return a + b;
	}

	double MyMathFuncs::Subtract(double a, double b)
	{
		return a - b;
	}

	double MyMathFuncs::Multiply(double a, double b)
	{
		return a * b;
	}

	double MyMathFuncs::Divide(double a, double b)
	{
		return a / b;
	}
}
//============EXAMPLE===================


//=======================================================MATRIX3======================================

//=======================rotation================
//=======================================================MATRIX3======================================





//=====================================MATRIX 4========================================================



//=====================================MATRIX 4========================================================


